jRhodes3d MINI - FIZZY ORANGE example
=====================================

Reduced subset of https://github.com/sfzinstruments/jlearman.jRhodes3d
Control files and example clips: CC0. Samples: CC BY 4.0.

Samples are from (or based on, if that's the case) jRhodes3d -
https://github.com/sfzinstruments/jlearman.jRhodes3d

This package keeps 2 velocity layers at 8 sampled notes. Original full-length
FLAC samples were converted to 16-bit mono WAV at 22050 Hz and trimmed to 3
seconds. The SFZ was reduced to the firmware-supported subset. This is a
playable teaching example, not the full original instrument.

Subset: 16 samples, 8 notes (E2, D3, G3, D4, F4, B4, E5, A5), approx. 2.02 MB WAV payload.
