Osiris Piano MINI - FIZZY ORANGE example
========================================

Reduced subset of https://github.com/sfzinstruments/Osiris_Piano
License: CC0 1.0 Universal (see the source repository LICENSE file).

This package keeps MicA velocity layers 1 and 2 at 8 sampled notes across the
lower/middle keyboard. Original stereo FLAC samples were downmixed to mono,
converted to 16-bit WAV at 22050 Hz and trimmed to 3 seconds. The SFZ was
rewritten from the original mapping modules to use only the opcodes understood
by FIZZY ORANGE. This is a playable teaching example, not the full original
instrument.

Subset: 16 samples, 8 notes (C3, E3, G3, C4, E4, G4, C5, E5), approx. 2.02 MB WAV payload.
