SteelDrum MINI - FIZZY ORANGE example
=====================================

Reduced subset of https://github.com/sfzinstruments/jlearman.SteelDrum
License: Unlicense / public domain (see the source repository LICENSE file).

This package keeps 2 dynamics at 12 chromatic notes (C4-B4). Original stereo
FLAC samples were downmixed to mono, converted to 16-bit WAV at 22050 Hz and
trimmed to 2.5 seconds. One main take was chosen from each original round-robin
set. The SFZ was reduced to the firmware-supported subset and uses one_shot
playback, as in the original instrument.

Subset: 24 samples, 12 notes (C4, C#4, D4, D#4, E4, F4, F#4, G4, G#4, A4, A#4, B4), approx. 1.93 MB WAV payload.
