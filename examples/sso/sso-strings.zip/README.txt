SSO STRINGS MINI - FIZZY ORANGE example
================

Reduced subset of the Sonatina Symphonic Orchestra (SSO):
https://github.com/peastman/sso/tree/master/Sonatina%20Symphonic%20Orchestra

License: Creative Commons Sampling Plus 1.0 (noncommercial use, with
attribution). See https://creativecommons.org/licenses/sampling+/1.0/ and the
source repository LICENSE file. The original library was created by Mattias
Westlund; this repository is maintained by peastman. SSO incorporates samples
from many free/CC/public-domain sources; full provenance notes are in the
source README and LICENSE.

Four string sections: 1st violins, celli, basses and violas.

This package contains 24 samples from 1ST VIOLINS, CELLI, BASSES, VIOLAS. Samples were converted
to 16-bit mono WAV at 22050 Hz and shortened to keep the package inside the
FIZZY ORANGE limits (64 files and 16 MB decoded PCM). Source SFZ includes and
macros were flattened, and only firmware-supported opcodes are used. This is a
playable teaching example, not the full original instrument.
